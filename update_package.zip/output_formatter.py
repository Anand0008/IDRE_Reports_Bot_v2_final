"""
Output Formatter Agent

Runs after the Executor and before the Response Formatter.
Automatically detects column types in the result rows and applies
human-readable formatting in-place, so all downstream agents
(Response Formatter, Feedback Store, CSV download) see clean data.

Detection strategy (in priority order):
  1. Column name pattern matching (e.g. "amount", "date", "days")
  2. Python type inspection of the first non-null value in the column
  3. Falls back to leaving the value unchanged

Formatting applied:
  - Currency columns  → $1,234.56
  - Date / datetime   → Apr 2, 2025
  - Days / duration   → "42 days"
  - Large integers    → 1,234,567  (comma-separated, no $ prefix)
"""
import re
from datetime import date, datetime
from decimal import Decimal

from state.context import GraphState

# ── Column-name pattern dictionaries ──────────────────────────────────────────

_CURRENCY_COL = re.compile(
    r"\b(amount|balance|payment|fee|total|revenue|cost|price|value|sum|"
    r"disbursement|refund|charge|paid|owed|earned|dollar|usd|money)\b",
    re.IGNORECASE,
)

_DATE_COL = re.compile(
    r"\b(date|time|_at|_on|created|updated|closed|opened|filed|submitted|"
    r"received|rendered|changed|month|year|day|period|timestamp|due)\b",
    re.IGNORECASE,
)

_DAYS_COL = re.compile(
    r"\b(days|age|duration|elapsed|pending_days|open_days|turnaround|lag)\b",
    re.IGNORECASE,
)

_COUNT_COL = re.compile(
    r"\b(count|total|num|number|qty|quantity|n_|cnt)\b",
    re.IGNORECASE,
)

# ── Value formatters ───────────────────────────────────────────────────────────

def _fmt_currency(val) -> str:
    try:
        f = float(val)
        return f"${f:,.2f}"
    except (TypeError, ValueError):
        return str(val)


def _fmt_date(val) -> str:
    def _clean(dt: datetime) -> str:
        day = dt.strftime("%d").lstrip("0")
        has_time = dt.hour or dt.minute
        if has_time:
            return dt.strftime(f"%b {day}, %Y %H:%M")
        return dt.strftime(f"%b {day}, %Y")

    if isinstance(val, datetime):
        return _clean(val)
    if isinstance(val, date):
        day = val.strftime("%d").lstrip("0")
        return val.strftime(f"%b {day}, %Y")
    if isinstance(val, str):
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M:%S.%f", "%Y-%m-%d", "%Y-%m"):
            try:
                dt = datetime.strptime(val.strip(), fmt)
                if fmt == "%Y-%m":
                    return dt.strftime("%b %Y")
                return _clean(dt)
            except ValueError:
                continue
    return str(val)


def _fmt_days(val) -> str:
    try:
        n = int(float(val))
        return f"{n:,} days"
    except (TypeError, ValueError):
        return str(val)


def _fmt_count(val) -> str:
    try:
        n = int(float(val))
        return f"{n:,}"
    except (TypeError, ValueError):
        return str(val)


# ── Column type detection ──────────────────────────────────────────────────────

def _detect_col_type(col_name: str, sample_vals: list) -> str:
    """Return 'currency', 'date', 'days', 'count', or 'raw'."""
    # First check name patterns
    if _CURRENCY_COL.search(col_name):
        return "currency"
    if _DATE_COL.search(col_name):
        return "date"
    if _DAYS_COL.search(col_name):
        return "days"
    if _COUNT_COL.search(col_name):
        return "count"

    # Check value types if column name didn't match
    for v in sample_vals:
        if v is None:
            continue
        if isinstance(v, (date, datetime)):
            return "date"
        if isinstance(v, Decimal):
            # Decimal with scale > 0 is currency-like
            if v != int(v):
                return "currency"
        break  # Only inspect first non-null

    return "raw"


# ── Main formatting logic ──────────────────────────────────────────────────────

def _format_rows(rows: list) -> list:
    """Return a new list of dicts with values formatted in-place."""
    if not rows:
        return rows

    cols = list(rows[0].keys())

    # Build type map per column (sample first 5 non-null values per col)
    col_types = {}
    for col in cols:
        sample = [r[col] for r in rows[:10] if r.get(col) is not None]
        col_types[col] = _detect_col_type(col, sample)

    formatted = []
    for row in rows:
        new_row = {}
        for col in cols:
            val = row[col]
            if val is None:
                new_row[col] = None
                continue
            ctype = col_types[col]
            if ctype == "currency":
                new_row[col] = _fmt_currency(val)
            elif ctype == "date":
                new_row[col] = _fmt_date(val)
            elif ctype == "days":
                new_row[col] = _fmt_days(val)
            elif ctype == "count":
                new_row[col] = _fmt_count(val)
            else:
                new_row[col] = val
        formatted.append(new_row)

    return formatted


# ── LangGraph node ─────────────────────────────────────────────────────────────

def output_formatter_node(state: GraphState) -> GraphState:
    rows = state.get("query_result")
    if not rows:
        return state

    formatted = _format_rows(rows)

    col_types_summary = {}
    if rows:
        cols = list(rows[0].keys())
        for col in cols:
            sample = [r[col] for r in rows[:10] if r.get(col) is not None]
            col_types_summary[col] = _detect_col_type(col, sample)

    applied = [f"{col}→{t}" for col, t in col_types_summary.items() if t != "raw"]

    trace_entry = {
        "agent": "Output Formatter",
        "status": "ok",
        "summary": (
            f"Formatted {len(applied)} column(s)" if applied
            else "No formatting needed — all columns are plain values"
        ),
        "detail": applied if applied else [],
    }

    return {
        **state,
        "query_result": formatted,
        "agent_trace": state.get("agent_trace", []) + [trace_entry],
    }
