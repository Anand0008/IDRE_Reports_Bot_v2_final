from typing import Optional, List, Any, Dict
from typing_extensions import TypedDict


class GraphState(TypedDict):
    """State object that flows through the LangGraph pipeline."""
    user_query: str
    session_id: str

    # Access control (Story 6.1)
    user_role: str              # 'ES' | 'FA' | 'OM' | 'CEA' | 'DQD' (default: 'ES')
    permitted_tables: List[str] # resolved from access_control.json by Context Loader

    # Session memory (Story 2.2)
    conversation_history: List[Dict[str, str]]  # [{query, summary}, ...] last N turns
    resolved_query: str                         # user_query after pronoun/reference expansion

    # Schema mapping
    relevant_tables: List[str]
    schema_context: str

    # SQL generation
    generated_sql: str
    validated_sql: str

    # Execution
    query_result: Optional[List[Dict[str, Any]]]
    row_count: int
    execution_error: Optional[str]

    # Ambiguity scoring (Story 3.1)
    ambiguity_score: float          # 0.0 – 1.0
    ambiguity_flags: List[str]      # triggered flag keys

    # Business Glossary (Story 4.2)
    glossary_matches: List[Dict[str, Any]]  # matched glossary entries from query scan

    # Clarification (Story 3.2)
    needs_clarification: bool       # True = pipeline paused, question returned to user
    clarification_question: str     # the question shown to the user
    clarification_attempted: bool   # True = re-run after user answered; skip re-clarifying

    # Response
    formatted_response: str
    assumptions: List[str]        # interpretive decisions made by the SQL writer (Story 3.3)
    response_format: str          # 'number' | 'bar_chart' | 'line_chart' | 'pie_chart' | 'table' (Story 7.1)
    chart_config: Optional[Dict[str, Any]]  # chart rendering metadata (Story 7.1)
    query_explanation: str        # plain-English explanation of the SQL (Story 7.2)
    proactive_suggestions: List[str]  # 2-3 follow-up question suggestions (Story 7.3)

    # Pipeline control
    retry_count: int
    error_message: str
    retry_context: str   # Debugger-generated guidance string fed back to SQL Writer (Story 5.1)

    # Audit / timing (Story 8.2)
    pipeline_start_ms: int          # epoch ms when run_query was called
    agent_timings: Dict[str, int]   # ms per agent node

    # Token usage — accumulated across all LLM calls
    # { "Agent Name": {"input": int, "output": int, "total": int}, ... }
    token_usage: Dict[str, Any]

    # Structured trace — each entry is a dict:
    # { agent, status ("ok"|"warn"|"error"), summary, detail (list[str], optional) }
    agent_trace: List[Dict[str, Any]]

    # ── Feedback & Reproducibility System ─────────────────────────────────────
    user_identity: str                              # display handle set after password gate
    feedback_correction_context: Optional[Dict[str, Any]]  # None on normal runs
    is_feedback_retry: bool                         # True = this run was triggered by feedback "No"
    feedback_record_id: str                         # cross-reference to originating FeedbackRecord
