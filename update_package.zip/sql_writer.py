"""
SQL Writer Agent  (updated for Story 3.3 — Assumption Annotation)
1. Checks metric_cards.json for an exact/fuzzy NL trigger match (fast path).
2. Falls back to Gemini 3.1 Pro with schema context.

The LLM is instructed to append an ASSUMPTIONS: block after the SQL whenever it
makes any interpretive decision.  _parse_llm_response() splits the two parts.
"""
import json
import os
import re
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.messages import SystemMessage, HumanMessage
from config.settings import get_settings
from state.context import GraphState

METRIC_CARDS_PATH = os.path.join(os.path.dirname(__file__), "..", "config", "metric_cards.json")

SYSTEM_PROMPT = """You are a MySQL expert writing SELECT queries for the IDRE dispute resolution platform.

Rules you MUST follow:
1. Only write SELECT statements — no INSERT, UPDATE, DELETE, DROP, CREATE, ALTER, TRUNCATE, EXEC, or CALL.
2. Always quote table names with backticks (MySQL style). The table named `case` is a reserved word — always backtick it.
3. Add LIMIT 1000 unless the query is a COUNT/SUM/aggregate returning a single row.
4. Use column aliases that are human-readable (e.g., AS total_disputes, AS avg_amount).
5. Use only tables and columns listed in the schema context below.
6. When filtering by status, use the exact status string values (e.g., 'INITIAL_ELIGIBILITY_REVIEW').
7. If the query contains " — clarification: ", the text before it is the original question and
   the text after it is the user's answer to a clarification question. Combine both parts to
   produce a precise query. The clarification answer takes priority over any ambiguous part of
   the original question (e.g., if clarification says "approved and pending", filter on those
   payment statuses; if it says "last month", use that as the date range).
8. If the schema context contains a "GLOSSARY TERMS DETECTED" block, you MUST include each
   listed SQL filter verbatim in your WHERE clause. Do not rephrase, omit, or alter them.
   These filters represent agreed business definitions and must be applied exactly as stated.
9. After the SQL, if you made ANY interpretive decision — such as choosing a date range for
   a vague word like "recent", picking specific status values, defaulting to a particular
   organisation, or inferring a filter not explicitly stated — list each one on its own line
   under the heading ASSUMPTIONS: (one bullet per line, starting with "- ").
   If you made no interpretive decisions at all, omit the ASSUMPTIONS block entirely.

Output format (when assumptions exist):
<SQL statement>

ASSUMPTIONS:
- <assumption 1>
- <assumption 2>

Output format (when no assumptions):
<SQL statement>

Schema context:
{schema_context}

If prior query failed with this error, fix the query:
{error_context}
"""


_BREAKDOWN_WORDS = re.compile(
    r"\b(by|per|group|breakdown|split|each|list|show|which|who|detail|"
    r"organisation|organization|region|status|type|category|compare|"
    r"between|versus|vs|trend|over time|monthly|daily|weekly)\b",
    re.IGNORECASE,
)
_COUNT_INTENT = re.compile(
    r"^(how many|what is the (total|count|number)|count of|total number|"
    r"number of|how much|what('s| is) the)",
    re.IGNORECASE,
)


def _check_metric_cards(query: str) -> str:
    """
    Fast path: return a pre-verified SQL template when the query is clearly
    asking for a single aggregate metric with no breakdown or detail intent.

    Guards applied before matching:
    - Query must start with a count/total question word pattern.
    - Query must not contain breakdown/grouping/detail keywords.
    - Query must be short (≤ 12 words) — longer queries almost always need
      custom SQL (filters, joins, groupings).
    """
    if not os.path.exists(METRIC_CARDS_PATH):
        return None

    word_count = len(query.split())
    if word_count > 12:
        return None
    if not _COUNT_INTENT.match(query.strip()):
        return None
    if _BREAKDOWN_WORDS.search(query):
        return None

    with open(METRIC_CARDS_PATH) as f:
        cards = json.load(f)

    query_lower = query.lower()
    for metric in cards.get("metrics", []):
        for trigger in metric.get("nl_triggers", []):
            if trigger.lower() in query_lower:
                return metric["sql"]
    return None


def _parse_llm_response(raw: str) -> tuple[str, list[str]]:
    """
    Split the raw LLM output into (sql, assumptions).
    Looks for an ASSUMPTIONS: header anywhere after the first line.
    Returns (full_raw_stripped, []) if no ASSUMPTIONS block is found.
    """
    match = re.search(r"\nASSUMPTIONS\s*:\s*\n", raw, re.IGNORECASE)
    if not match:
        sql_part = raw.strip()
        # Strip trailing markdown fence if present
        sql_part = re.sub(r"\s*```\s*$", "", sql_part)
        return sql_part, []

    sql_part = raw[: match.start()].strip()
    # Strip trailing markdown fence from SQL if present
    sql_part = re.sub(r"\s*```\s*$", "", sql_part)

    assumptions_raw = raw[match.end() :].strip()

    assumptions = []
    for line in assumptions_raw.splitlines():
        cleaned = line.strip().lstrip("-").lstrip("*").strip()
        # Skip lines that are just markdown fences
        if cleaned and not cleaned.startswith("```"):
            assumptions.append(cleaned)

    return sql_part, assumptions


def _extract_token_usage(response) -> dict:
    usage = getattr(response, "usage_metadata", None) or {}
    return {
        "input":  int(usage.get("input_tokens", 0)),
        "output": int(usage.get("output_tokens", 0)),
        "total":  int(usage.get("total_tokens", 0)),
    }


def _generate_sql_with_llm(
    query: str, schema_context: str, error_context: str = ""
) -> tuple[str, list[str], dict]:
    """Returns (sql, assumptions, token_usage)."""
    settings = get_settings()
    llm = ChatGoogleGenerativeAI(
        model="gemini-3.1-pro-preview",
        temperature=0,
        google_api_key=settings.gemini_api_key,
    )
    system = SYSTEM_PROMPT.format(
        schema_context=schema_context,
        error_context=error_context or "None",
    )
    messages = [SystemMessage(content=system), HumanMessage(content=query)]
    response = llm.invoke(messages)
    content = response.content
    if isinstance(content, list):
        content = "".join(c.get("text", str(c)) if isinstance(c, dict) else str(c) for c in content)
    raw = content.strip()

    raw = re.sub(r"^```(?:sql)?\s*", "", raw, flags=re.IGNORECASE)
    raw = re.sub(r"\s*```$", "", raw)

    sql, assumptions = _parse_llm_response(raw)
    return sql, assumptions, _extract_token_usage(response)


def sql_writer_node(state: GraphState) -> GraphState:
    # Use resolved_query if available (Story 2.2), else fall back to raw query
    query = state.get("resolved_query") or state["user_query"]
    schema_context = state.get("schema_context", "")
    # Prefer debugger-analyzed retry_context over raw execution_error (Story 5.2)
    error_context = state.get("retry_context", "") or state.get("execution_error", "") or ""
    retry_count = state.get("retry_count", 0)

    # Fast path: metric card match (only on first attempt) — no assumptions
    if retry_count == 0:
        sql = _check_metric_cards(query)
        if sql:
            trace_entry = {
                "agent": "SQL Writer",
                "status": "ok",
                "summary": "Served from metric card (fast path — no LLM call needed)",
                "detail": [],
            }
            trace = state.get("agent_trace", []) + [trace_entry]
            return {**state, "generated_sql": sql, "assumptions": [], "agent_trace": trace}

    # LLM path
    sql, assumptions, tok = _generate_sql_with_llm(query, schema_context, error_context)
    token_usage = dict(state.get("token_usage") or {})
    writer_key = "SQL Writer" if retry_count == 0 else f"SQL Writer (retry {retry_count})"
    token_usage[writer_key] = tok

    label = "Retry" if retry_count > 0 else "Attempt 1"
    detail = []
    if error_context:
        detail.append(f"Previous error: {error_context[:120]}")
    glossary_matches = state.get("glossary_matches", [])
    if glossary_matches:
        terms = [m["term"] for m in glossary_matches]
        detail.append(f"Glossary filters applied: {', '.join(terms)}")
    if assumptions:
        detail.append(f"{len(assumptions)} assumption(s) annotated")

    trace_entry = {
        "agent": "SQL Writer",
        "status": "ok",
        "summary": f"SQL generated via Gemini 3.1 Pro · {label}"
        + (f" · {len(assumptions)} assumption(s)" if assumptions else ""),
        "detail": detail,
    }
    trace = state.get("agent_trace", []) + [trace_entry]
    return {
        **state,
        "generated_sql":   sql,
        "assumptions":     assumptions,
        "agent_trace":     trace,
        "execution_error": None,
        "token_usage":     token_usage,
    }
