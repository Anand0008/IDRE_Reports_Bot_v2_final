"""
SQL Validator Agent
Deterministic safety checks — no LLM involved.
Blocks DDL/DML, verifies tables exist, ensures query is SELECT-only.
"""
import re
import json
import os
from state.context import GraphState

SCHEMA_CATALOG_PATH = os.path.join(os.path.dirname(__file__), "..", "schema_catalog.json")

BLOCKED_KEYWORDS = re.compile(
    r"\b(INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|TRUNCATE|EXEC|EXECUTE|CALL|GRANT|REVOKE|LOAD|OUTFILE|DUMPFILE)\b",
    re.IGNORECASE,
)


def _get_known_tables() -> set:
    with open(SCHEMA_CATALOG_PATH) as f:
        catalog = json.load(f)
    return set(catalog["tables"].keys())


def _extract_table_names(sql: str) -> list[str]:
    """Rough extraction of table names from FROM and JOIN clauses."""
    # Remove backtick quoting for matching
    normalized = sql.replace("`", "")
    pattern = re.compile(r"\b(?:FROM|JOIN)\s+(\w+)", re.IGNORECASE)
    return pattern.findall(normalized)


def validate_sql(sql: str, permitted_tables: list = None) -> tuple:
    """
    Returns (is_valid, error_message).
    error_message is empty string if valid.
    permitted_tables: if provided, any referenced table outside this list is blocked.
    """
    if not sql or not sql.strip():
        return False, "Empty SQL generated."

    stripped = sql.strip()

    # Must start with SELECT
    if not re.match(r"^\s*SELECT\b", stripped, re.IGNORECASE):
        return False, f"Query must be a SELECT statement. Got: {stripped[:60]}"

    # Block dangerous keywords
    match = BLOCKED_KEYWORDS.search(stripped)
    if match:
        return False, f"Blocked keyword '{match.group()}' found in query."

    # Block multiple statements
    if stripped.rstrip(";").count(";") > 0:
        return False, "Multiple SQL statements are not allowed."

    # Check that referenced tables exist in the catalog
    known = _get_known_tables()
    referenced = _extract_table_names(stripped)
    unknown = [t for t in referenced if t not in known]
    if unknown:
        return False, f"Unknown table(s) referenced: {unknown}. Check spelling or schema."

    # Story 6.3 — permission re-check (defense-in-depth)
    if permitted_tables:
        unauthorized = [t for t in referenced if t not in permitted_tables]
        if unauthorized:
            # Do NOT reveal the table name — attacker should not learn what restricted tables exist
            return False, "Query references table(s) that are not accessible for your role."

    return True, ""


def sql_validator_node(state: GraphState) -> GraphState:
    sql = state.get("generated_sql", "")
    permitted = state.get("permitted_tables") or None
    is_valid, error = validate_sql(sql, permitted_tables=permitted)
    trace = state.get("agent_trace", [])

    if is_valid:
        tables_used = _extract_table_names(sql)
        trace_entry = {
            "agent": "SQL Validator",
            "status": "ok",
            "summary": f"Passed all safety checks · {len(tables_used)} table(s) referenced",
            "detail": [f"Tables in query: {', '.join(tables_used)}"] if tables_used else [],
        }
        trace = trace + [trace_entry]
        return {**state, "validated_sql": sql, "error_message": "", "agent_trace": trace}
    else:
        is_permission_violation = "not accessible for your role" in error
        trace_entry = {
            "agent": "SQL Validator",
            "status": "error",
            "summary": "Permission violation — query blocked" if is_permission_violation else "Validation failed — query blocked",
            "detail": [error],
        }
        trace = trace + [trace_entry]
        return {**state, "validated_sql": "", "error_message": error, "agent_trace": trace}
